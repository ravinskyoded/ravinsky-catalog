window.products = [
  {
    "name": "acqua_bella",
    "path": "images/products/granite/acqua_bella/",
    "main": "acqua_bella_main.jpg",
    "images": [
      "acqua_bella_main.jpg"
    ],
    "thumbnails": [
      "thumbnails/acqua_bella_main.jpg"
    ]
  },
  {
    "name": "black_mist",
    "path": "images/products/granite/black_mist/",
    "main": "black_mist_01.jpg",
    "images": [
      "black_mist_01.jpg",
      "black_mist_02.jpg",
      "black_mist_03.jpg",
      "black_mist_04.jpg",
      "black_mist_05.jpg",
      "black_mist_06.jpg",
      "black_mist_07.jpg",
      "black_mist_08.jpg",
      "black_mist_09.jpg",
      "black_mist_main.jpg"
    ],
    "thumbnails": [
      "thumbnails/black_mist_01.jpg",
      "thumbnails/black_mist_02.jpg",
      "thumbnails/black_mist_03.jpg",
      "thumbnails/black_mist_04.jpg",
      "thumbnails/black_mist_05.jpg",
      "thumbnails/black_mist_06.jpg",
      "thumbnails/black_mist_07.jpg",
      "thumbnails/black_mist_08.jpg",
      "thumbnails/black_mist_09.jpg",
      "thumbnails/black_mist_main.jpg"
    ]
  },
  {
    "name": "cezanne",
    "path": "images/products/granite/cezanne/",
    "main": "cezanne_main.jpg",
    "images": [
      "cezanne_main.jpg"
    ],
    "thumbnails": [
      "thumbnails/cezanne_main.jpg"
    ]
  },
  {
    "name": "cristal_laguna_onixe",
    "path": "images/products/granite/cristal_laguna_onixe/",
    "main": "cristal_laguna_onixe_main.jpg",
    "images": [
      "cristal_laguna_onixe_main.jpg"
    ],
    "thumbnails": [
      "thumbnails/cristal_laguna_onixe_main.jpg"
    ]
  },
  {
    "name": "cristal_pink_onixe",
    "path": "images/products/granite/cristal_pink_onixe/",
    "main": "cristal_pink_onixe_main.jpg",
    "images": [
      "cristal_pink_onixe_main.jpg"
    ],
    "thumbnails": [
      "thumbnails/cristal_pink_onixe_main.jpg"
    ]
  },
  {
    "name": "cristallo_superior_onixe",
    "path": "images/products/granite/cristallo_superior_onixe/",
    "main": "cristallo_superior_onixe_main.jpg",
    "images": [
      "cristallo_superior_onixe_main.jpg"
    ],
    "thumbnails": [
      "thumbnails/cristallo_superior_onixe_main.jpg"
    ]
  },
  {
    "name": "esmeralda",
    "path": "images/products/granite/esmeralda/",
    "main": "esmeralda_main.jpg",
    "images": [
      "esmeralda_main.jpg"
    ],
    "thumbnails": [
      "thumbnails/esmeralda_main.jpg"
    ]
  },
  {
    "name": "explosione_blue",
    "path": "images/products/granite/explosione_blue/",
    "main": "explosione_blue_02.jpg",
    "images": [
      "explosione_blue_02.jpg"
    ],
    "thumbnails": [
      "thumbnails/explosione_blue_02.jpg"
    ]
  },
  {
    "name": "infinity_gold",
    "path": "images/products/granite/infinity_gold/",
    "main": "infinity_gold_main.jpg",
    "images": [
      "infinity_gold_main.jpg"
    ],
    "thumbnails": [
      "thumbnails/infinity_gold_main.jpg"
    ]
  },
  {
    "name": "jupiter",
    "path": "images/products/granite/jupiter/",
    "main": "jupiter_main.jpg",
    "images": [
      "jupiter_main.jpg"
    ],
    "thumbnails": [
      "thumbnails/jupiter_main.jpg"
    ]
  },
  {
    "name": "michaelangelo",
    "path": "images/products/granite/michaelangelo/",
    "main": "michaelangelo_01.jpg",
    "images": [
      "michaelangelo_01.jpg",
      "michaelangelo_02.jpg",
      "michaelangelo_main.jpg"
    ],
    "thumbnails": [
      "thumbnails/michaelangelo_01.jpg",
      "thumbnails/michaelangelo_02.jpg",
      "thumbnails/michaelangelo_main.jpg"
    ]
  },
  {
    "name": "nacarado",
    "path": "images/products/granite/nacarado/",
    "main": "nacarado_main.jpg",
    "images": [
      "nacarado_main.jpg"
    ],
    "thumbnails": [
      "thumbnails/nacarado_main.jpg"
    ]
  },
  {
    "name": "negresco",
    "path": "images/products/granite/negresco/",
    "main": "negresco_01.jpg",
    "images": [
      "negresco_01.jpg",
      "negresco_02.jpg",
      "negresco_03.jpg",
      "negresco_04.jpg",
      "negresco_05.jpg",
      "negresco_06.jpg",
      "negresco_07.jpg",
      "negresco_08.jpg",
      "negresco_main.jpg",
      "WhatsApp_Image_2026-01-05_at_14.02.56.jpeg",
      "WhatsApp_Image_2026-01-05_at_14.02.57.jpeg"
    ],
    "thumbnails": [
      "thumbnails/negresco_01.jpg",
      "thumbnails/negresco_02.jpg",
      "thumbnails/negresco_03.jpg",
      "thumbnails/negresco_04.jpg",
      "thumbnails/negresco_05.jpg",
      "thumbnails/negresco_06.jpg",
      "thumbnails/negresco_07.jpg",
      "thumbnails/negresco_08.jpg",
      "thumbnails/negresco_main.jpg",
      "thumbnails/WhatsApp_Image_2026-01-05_at_14.02.56.jpeg",
      "thumbnails/WhatsApp_Image_2026-01-05_at_14.02.57.jpeg"
    ]
  },
  {
    "name": "superlative",
    "path": "images/products/granite/superlative/",
    "main": "superlative_main.jpg",
    "images": [
      "superlative_main.jpg"
    ],
    "thumbnails": [
      "thumbnails/superlative_main.jpg"
    ]
  },
  {
    "name": "taj_mahal_matt",
    "path": "images/products/granite/taj_mahal_matt/",
    "main": "taj_mahal_matt_main.jpg",
    "images": [
      "taj_mahal_matt_main.jpg",
      "WhatsApp Image 2026-03-15 at 11.52.23.jpeg",
      "WhatsApp Image 2026-03-15 at 11.52.42.jpeg",
      "WhatsApp_Image_2026-03-15_at_11.52.23.jpeg",
      "WhatsApp_Image_2026-03-15_at_11.52.42.jpeg",
      "WhatsApp_Image_2026-03-15_at_11.53.10.jpeg"
    ],
    "thumbnails": [
      "thumbnails/taj_mahal_matt_main.jpg",
      "thumbnails/WhatsApp Image 2026-03-15 at 11.52.23.jpeg",
      "thumbnails/WhatsApp Image 2026-03-15 at 11.52.42.jpeg",
      "thumbnails/WhatsApp_Image_2026-03-15_at_11.52.23.jpeg",
      "thumbnails/WhatsApp_Image_2026-03-15_at_11.52.42.jpeg",
      "thumbnails/WhatsApp_Image_2026-03-15_at_11.53.10.jpeg"
    ]
  },
  {
    "name": "taj_mahal_polished",
    "path": "images/products/granite/taj_mahal_polished/",
    "main": "taj_mahal_polished_01.jpg",
    "images": [
      "taj_mahal_polished_01.jpg",
      "taj_mahal_polished_02.jpg",
      "taj_mahal_polished_03.jpg",
      "taj_mahal_polished_04.jpg",
      "taj_mahal_polished_05.jpg",
      "taj_mahal_polished_06.jpg",
      "taj_mahal_polished_07.jpg",
      "taj_mahal_polished_08.jpg",
      "taj_mahal_polished_09.jpg",
      "taj_mahal_polished_main.jpg",
      "WhatsApp_Image_2026-01-26_at_16.46.45.jpeg",
      "WhatsApp_Image_2026-01-26_at_16.46.45_(1).jpeg",
      "WhatsApp_Image_2026-01-26_at_16.46.46.jpeg",
      "WhatsApp_Image_2026-01-26_at_16.46.46_(1).jpeg",
      "WhatsApp_Image_2026-01-26_at_16.46.46_(2).jpeg",
      "WhatsApp_Image_2026-01-26_at_16.46.47.jpeg",
      "WhatsApp_Image_2026-01-26_at_16.46.47_(1).jpeg",
      "WhatsApp_Image_2026-01-26_at_16.46.47_(2).jpeg",
      "WhatsApp_Image_2026-01-26_at_16.46.47_(4).jpeg",
      "WhatsApp_Image_2026-01-26_at_16.46.48.jpeg",
      "WhatsApp_Image_2026-01-26_at_16.46.48_(1).jpeg",
      "WhatsApp_Image_2026-01-26_at_16.46.48_(2).jpeg"
    ],
    "thumbnails": [
      "thumbnails/taj_mahal_polished_01.jpg",
      "thumbnails/taj_mahal_polished_02.jpg",
      "thumbnails/taj_mahal_polished_03.jpg",
      "thumbnails/taj_mahal_polished_04.jpg",
      "thumbnails/taj_mahal_polished_05.jpg",
      "thumbnails/taj_mahal_polished_06.jpg",
      "thumbnails/taj_mahal_polished_07.jpg",
      "thumbnails/taj_mahal_polished_08.jpg",
      "thumbnails/taj_mahal_polished_09.jpg",
      "thumbnails/taj_mahal_polished_main.jpg",
      "thumbnails/WhatsApp_Image_2026-01-26_at_16.46.45.jpeg",
      "thumbnails/WhatsApp_Image_2026-01-26_at_16.46.45_(1).jpeg",
      "thumbnails/WhatsApp_Image_2026-01-26_at_16.46.46.jpeg",
      "thumbnails/WhatsApp_Image_2026-01-26_at_16.46.46_(1).jpeg",
      "thumbnails/WhatsApp_Image_2026-01-26_at_16.46.46_(2).jpeg",
      "thumbnails/WhatsApp_Image_2026-01-26_at_16.46.47.jpeg",
      "thumbnails/WhatsApp_Image_2026-01-26_at_16.46.47_(1).jpeg",
      "thumbnails/WhatsApp_Image_2026-01-26_at_16.46.47_(2).jpeg",
      "thumbnails/WhatsApp_Image_2026-01-26_at_16.46.47_(4).jpeg",
      "thumbnails/WhatsApp_Image_2026-01-26_at_16.46.48.jpeg",
      "thumbnails/WhatsApp_Image_2026-01-26_at_16.46.48_(1).jpeg",
      "thumbnails/WhatsApp_Image_2026-01-26_at_16.46.48_(2).jpeg"
    ]
  },
  {
    "name": "titanium",
    "path": "images/products/granite/titanium/",
    "main": "titanium_main.jpg",
    "images": [
      "titanium_main.jpg"
    ],
    "thumbnails": [
      "thumbnails/titanium_main.jpg"
    ]
  }
];
