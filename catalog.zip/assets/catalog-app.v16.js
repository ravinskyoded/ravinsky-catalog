(function () {
  const byId = id => document.getElementById(id);

  /* ===== כפתורי עליון ===== */
  byId('btnRefresh')?.addEventListener('click', ()=>location.reload(true));
  byId('btnExit')?.addEventListener('click', async () => {
    // Block exit if an update is running
    try {
      const s = await fetch('http://127.0.0.1:8765/status').then(r => r.json()).catch(() => null);
      if (s && s.running) {
        alert('עדכון פעיל ברקע — נא להמתין לסיום העדכון לפני יציאה.');
        return;
      }
    } catch (e) {}
    // PLUS license: fully.exit() actually quits the app
    try {
      if (window.fully && typeof fully.exit === 'function') {
        fully.exit();
        return;
      }
    } catch (e) {}
    // Fallback (Free or fully.exit unavailable): backend HOME intent
    try {
      const key = localStorage.getItem('updateKey') || '1234';
      await fetch('http://127.0.0.1:8765/exit?key=' + encodeURIComponent(key));
    } catch (e) {}
  });

/* ===== כפתור "עדכון" עם מסך התקדמות ===== */
(function wireUpdate() {
  const byText = (txt) =>
    [...document.querySelectorAll('button')]
      .find(b => (b.textContent || '').trim().includes(txt));
  const updateBtn =
    document.getElementById('btnUpdate') ||
    byText('עדכון');

  if (!updateBtn || updateBtn._wired) return;
  updateBtn._wired = true;

  /* --- Progress overlay CSS --- */
  const style = document.createElement('style');
  style.textContent = `
    #upd-confirm{position:fixed;inset:0;background:rgba(0,0,0,.85);
      display:none;align-items:center;justify-content:center;z-index:10001;
      font-family:Arial,sans-serif;color:#e6ecf2;direction:rtl}
    #upd-confirm.show{display:flex}
    .upd-confirm-card{background:#1a1f26;border:1px solid #444;border-radius:14px;
      padding:32px 36px;max-width:480px;text-align:center;box-shadow:0 8px 30px rgba(0,0,0,.6)}
    .upd-confirm-title{font-size:24px;font-weight:bold;margin-bottom:16px;color:#fff}
    .upd-confirm-text{font-size:16px;line-height:1.7;margin-bottom:28px;color:#ccd}
    .upd-confirm-text strong{color:#ffcc66}
    .upd-confirm-buttons{display:flex;gap:14px;justify-content:center}
    .upd-confirm-buttons button{padding:12px 28px;font-size:16px;border-radius:10px;
      cursor:pointer;border:2px solid;font-weight:bold;min-width:130px;
      font-family:inherit}
    #upd-confirm-no{background:#88aaff;color:#0b0e12;border-color:#88aaff}
    #upd-confirm-no:focus{outline:4px solid #88aaff;outline-offset:3px}
    #upd-confirm-yes{background:transparent;color:#f88;border-color:#f88}
    #upd-confirm-yes:hover{background:rgba(248,136,136,.12)}
    #upd-overlay{position:fixed;inset:0;background:rgba(11,14,18,.94);
      display:none;flex-direction:column;align-items:center;justify-content:center;z-index:10000;
      font-family:Arial,sans-serif;color:#e6ecf2;direction:rtl}
    #upd-overlay.show{display:flex}
    #upd-spinner{width:64px;height:64px;border:5px solid #333;border-top-color:#4CAF50;
      border-radius:50%;animation:upd-spin 1s linear infinite;margin-bottom:28px}
    @keyframes upd-spin{to{transform:rotate(360deg)}}
    #upd-step{font-size:22px;font-weight:bold;margin-bottom:12px}
    #upd-file{font-size:14px;color:#8899aa;margin-bottom:24px;max-width:80vw;
      overflow:hidden;text-overflow:ellipsis;white-space:nowrap;text-align:center}
    #upd-bar-wrap{width:280px;height:8px;background:#222;border-radius:4px;overflow:hidden;margin-bottom:16px}
    #upd-bar{height:100%;width:0%;background:linear-gradient(90deg,#4CAF50,#66bb6a);
      border-radius:4px;transition:width .5s ease}
    #upd-elapsed{font-size:13px;color:#667788}
    #upd-done-icon{font-size:56px;margin-bottom:16px;display:none}
    #upd-error-msg{font-size:14px;color:#f88;margin-top:8px;display:none;max-width:70vw;text-align:center}
    #upd-close{margin-top:20px;display:none;background:#4CAF50;color:#fff;border:none;
      border-radius:8px;padding:10px 32px;font-size:16px;cursor:pointer}
    #upd-minimize{margin-top:12px;background:transparent;color:#88aaff;border:2px solid #88aaff;
      border-radius:8px;padding:10px 24px;font-size:15px;cursor:pointer;font-family:inherit}
    #upd-minimize:hover{background:rgba(136,170,255,.12)}
    #upd-badge{display:none;background:#1a1f26;border:1px solid #4CAF50;
      border-radius:24px;padding:6px 14px;margin:0 12px;color:#e6ecf2;font-family:Arial,sans-serif;
      font-size:13px;direction:rtl;cursor:pointer;align-items:center;gap:10px;
      max-width:340px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
    #upd-badge.show{display:inline-flex}
    #upd-badge.done{border-color:#4CAF50;background:#1f3a23}
    #upd-badge.err{border-color:#f44336;background:#3a1f1f}
    #upd-badge-spinner{width:14px;height:14px;border:2px solid #333;
      border-top-color:#4CAF50;border-radius:50%;animation:upd-spin 1s linear infinite}
    #upd-badge.done #upd-badge-spinner,#upd-badge.err #upd-badge-spinner{display:none}
  `;
  document.head.appendChild(style);

  /* --- Confirmation dialog HTML --- */
  const confirmDlg = document.createElement('div');
  confirmDlg.id = 'upd-confirm';
  confirmDlg.innerHTML = `
    <div class="upd-confirm-card">
      <div class="upd-confirm-title">אישור עדכון</div>
      <div class="upd-confirm-text">
        פעולה זו תסנכרן את הקטלוג מ-Google Drive.<br>
        <strong>זמן משוער: 5–35 דקות</strong><br>
        ניתן לסגור את ההודעה — העדכון ימשיך ברקע<br>
        והקטלוג נשאר זמין במהלך העדכון.
      </div>
      <div class="upd-confirm-buttons">
        <button id="upd-confirm-no" type="button">ביטול</button>
        <button id="upd-confirm-yes" type="button">אישור עדכון</button>
      </div>
    </div>
  `;
  document.body.appendChild(confirmDlg);

  function askConfirm() {
    return new Promise(resolve => {
      const btnNo  = document.getElementById('upd-confirm-no');
      const btnYes = document.getElementById('upd-confirm-yes');
      const cleanup = (result) => {
        confirmDlg.classList.remove('show');
        document.removeEventListener('keydown', onKey);
        confirmDlg.removeEventListener('click', onBackdrop);
        btnNo.removeEventListener('click', onNo);
        btnYes.removeEventListener('click', onYes);
        resolve(result);
      };
      const onKey = e => {
        if (e.key === 'Escape' || e.key === 'Enter') { e.preventDefault(); cleanup(false); }
      };
      const onBackdrop = e => { if (e.target === confirmDlg) cleanup(false); };
      const onNo  = () => cleanup(false);
      const onYes = () => cleanup(true);
      btnNo.addEventListener('click', onNo);
      btnYes.addEventListener('click', onYes);
      confirmDlg.addEventListener('click', onBackdrop);
      document.addEventListener('keydown', onKey);
      confirmDlg.classList.add('show');
      setTimeout(() => btnNo.focus(), 50);
    });
  }

  /* --- Progress overlay HTML --- */
  const overlay = document.createElement('div');
  overlay.id = 'upd-overlay';
  overlay.innerHTML = `
    <div id="upd-spinner"></div>
    <div id="upd-done-icon"></div>
    <div id="upd-step"></div>
    <div id="upd-file"></div>
    <div id="upd-bar-wrap"><div id="upd-bar"></div></div>
    <div id="upd-elapsed"></div>
    <div id="upd-error-msg"></div>
    <button id="upd-close">סגור</button>
    <button id="upd-minimize" type="button">סגור — העדכון ימשיך ברקע</button>
  `;
  document.body.appendChild(overlay);

  /* --- Background badge --- */
  const badge = document.createElement('div');
  badge.id = 'upd-badge';
  badge.innerHTML = `<div id="upd-badge-spinner"></div><span id="upd-badge-text">מעדכן...</span>`;
  // Insert into header between the update button and the brand title
  const updateBtnEl = document.getElementById('btnUpdate');
  if (updateBtnEl && updateBtnEl.parentNode) {
    updateBtnEl.parentNode.insertBefore(badge, updateBtnEl.nextSibling);
  } else {
    document.body.appendChild(badge);
  }

  const elSpinner = byId('upd-spinner');
  const elDoneIcon= byId('upd-done-icon');
  const elStep    = byId('upd-step');
  const elFile    = byId('upd-file');
  const elBar     = byId('upd-bar');
  const elElapsed = byId('upd-elapsed');
  const elError   = byId('upd-error-msg');
  const elClose   = byId('upd-close');
  const elMinimize= byId('upd-minimize');
  const elBadge   = byId('upd-badge');
  const elBadgeText = byId('upd-badge-text');

  elClose.addEventListener('click', () => {
    overlay.classList.remove('show');
    location.href = `index.html?nocache=${Date.now()}${location.hash||''}`;
  });

  elMinimize.addEventListener('click', () => {
    overlay.classList.remove('show');
    elBadge.classList.add('show');
  });

  elBadge.addEventListener('click', () => {
    if (elBadge.classList.contains('done')) {
      location.href = `index.html?nocache=${Date.now()}${location.hash||''}`;
      return;
    }
    elBadge.classList.remove('show');
    overlay.classList.add('show');
  });

  /* --- Step translations --- */
  const STEPS = {
    start:        { text: 'מתחיל עדכון...', pct: 5 },
    rclone_sync:  { text: 'מוריד קבצים מ-Google Drive...', pct: 15 },
    local_copy:   { text: 'מעתיק קבצים...', pct: 15 },
    verify:       { text: 'בודק תקינות...', pct: 85 },
    swap:         { text: 'מחליף גרסה...', pct: 92 },
    done:         { text: 'העדכון הושלם בהצלחה!', pct: 100 },
    failed_verify:{ text: 'העדכון נכשל - בדיקת תקינות', pct: 0 },
  };

  function parseLastFile(tail) {
    if (!tail) return '';
    const lines = tail.split('\n').filter(l => l.includes('Copied'));
    if (!lines.length) return '';
    const last = lines[lines.length - 1];
    const m = last.match(/:\s*(.+?):\s*Copied/);
    if (m) {
      const parts = m[1].split('/');
      return parts[parts.length - 1];
    }
    return '';
  }

  function countFiles(tail) {
    if (!tail) return 0;
    return (tail.match(/Copied \(new\)/g) || []).length;
  }

  // Parse rclone summary lines for accurate progress.
  // Looks for the latest occurrences of:
  //   "Transferred:          270 / 876, 31%"          (file count + %)
  //   "Transferred:   115.622 MiB / 175.632 MiB, 66%, 37.761 KiB/s, ETA 27m7s"  (bytes + ETA)
  function parseProgress(tail) {
    if (!tail) return null;
    const lines = tail.split('\n');
    let files = null, eta = null;
    for (let i = lines.length - 1; i >= 0; i--) {
      const l = lines[i];
      if (!files) {
        const m = l.match(/Transferred:\s+(\d+)\s*\/\s*(\d+),\s*(\d+)%\s*$/);
        if (m) files = { done: +m[1], total: +m[2], pct: +m[3] };
      }
      if (!eta) {
        const m = l.match(/Transferred:.*?ETA\s+(\S+)/);
        if (m) eta = m[1];
      }
      if (files && eta) break;
    }
    if (!files) return null;
    return { ...files, eta };
  }

  function formatTime(sec) {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    if (m > 0) return `${m} דקות ${s} שניות`;
    return `${s} שניות`;
  }

  function showProgress(step, tail, startTime) {
    const info = STEPS[step] || { text: step, pct: 10 };
    elStep.textContent = info.text;

    const prog = parseProgress(tail);

    // Progress bar — use real rclone percentage when available, otherwise animate
    let pct = info.pct;
    if (step === 'rclone_sync') {
      if (prog) {
        // Map rclone's 0–100% into the 15–80% region the UI reserves for sync
        pct = 15 + Math.min(prog.pct, 100) * 0.65;
      } else if (startTime) {
        const elapsed = (Date.now() - startTime) / 1000;
        pct = Math.min(80, 15 + (elapsed / 900) * 65);
      }
    }
    elBar.style.width = pct + '%';

    // File info
    const lastFile = parseLastFile(tail);
    const fallbackCount = countFiles(tail);
    if (prog) {
      elFile.textContent = lastFile
        ? `${prog.done} / ${prog.total} (${prog.pct}%) | ${lastFile}`
        : `${prog.done} / ${prog.total} (${prog.pct}%)`;
    } else if (lastFile) {
      elFile.textContent = `${fallbackCount} קבצים הורדו | ${lastFile}`;
    } else if (fallbackCount > 0) {
      elFile.textContent = `${fallbackCount} קבצים הורדו`;
    } else {
      elFile.textContent = '';
    }

    // Elapsed time (+ ETA when known)
    if (startTime) {
      const sec = Math.floor((Date.now() - startTime) / 1000);
      const elapsedTxt = formatTime(sec);
      elElapsed.textContent = (prog && prog.eta)
        ? `${elapsedTxt} | נותר ~${prog.eta}`
        : elapsedTxt;
    }

    // Mirror to badge (when minimized)
    const badgeSuffix = prog
      ? ` (${prog.done}/${prog.total}, ${prog.pct}%)`
      : (fallbackCount ? ` (${fallbackCount})` : '');
    elBadgeText.textContent = `מעדכן: ${info.text}${badgeSuffix}`;
  }

  function showDone(success, fileCount, errorMsg) {
    elSpinner.style.display = 'none';
    elDoneIcon.style.display = 'block';
    elBar.style.width = '100%';

    if (success) {
      elDoneIcon.textContent = '\u2714';
      elDoneIcon.style.color = '#4CAF50';
      if (fileCount > 0) {
        elStep.textContent = 'העדכון הושלם בהצלחה!';
        elFile.textContent = `${fileCount} קבצים עודכנו`;
      } else {
        elStep.textContent = 'מעודכן בגרסה האחרונה';
        elFile.textContent = 'אין קבצים חדשים לעדכן';
      }
      elBar.style.background = 'linear-gradient(90deg,#4CAF50,#66bb6a)';
    } else {
      elDoneIcon.textContent = '\u2718';
      elDoneIcon.style.color = '#f44336';
      elStep.textContent = 'העדכון נכשל';
      elBar.style.background = '#f44336';
      elBar.style.width = '100%';
      if (errorMsg) {
        elError.textContent = errorMsg;
        elError.style.display = 'block';
      }
    }
    elClose.style.display = 'inline-block';
    elMinimize.style.display = 'none';

    // Badge: switch to done/err state and keep visible
    elBadge.classList.remove('show');
    elBadge.classList.toggle('done', !!success);
    elBadge.classList.toggle('err', !success);
    elBadgeText.textContent = success
      ? (fileCount > 0 ? `✔ עודכן (${fileCount} קבצים) — לחץ לרענון` : '✔ מעודכן בגרסה האחרונה')
      : `✘ העדכון נכשל`;
    // If overlay was minimized, show the done badge
    if (!overlay.classList.contains('show')) elBadge.classList.add('show');
  }

  function resetOverlay() {
    elSpinner.style.display = 'block';
    elDoneIcon.style.display = 'none';
    elStep.textContent = '';
    elFile.textContent = '';
    elBar.style.width = '0%';
    elBar.style.background = 'linear-gradient(90deg,#4CAF50,#66bb6a)';
    elElapsed.textContent = '';
    elError.style.display = 'none';
    elError.textContent = '';
    elMinimize.style.display = 'inline-block';
    elBadge.classList.remove('show', 'done', 'err');
    elClose.style.display = 'none';
  }

  // Helpers
  const API = async (path, {method='GET', headers={}, body} = {}) => {
    const opts = { method, headers: {...headers} };
    if (body !== undefined) {
      opts.headers['Content-Type'] = 'application/json';
      opts.body = JSON.stringify(body);
    }
    const r = await fetch(`http://127.0.0.1:8765${path}`, opts);
    return r.json();
  };
  const getStatus = () => API('/status').catch(() => ({ok:false}));
  const getKey = () => localStorage.getItem('updateKey') || '';
  const setKey = k => localStorage.setItem('updateKey', k || '');

  const postUpdate = async () => {
    let key = getKey();
    if (!key) {
      key = prompt('סיסמת עדכון:') || '';
      if (!key) throw new Error('בוטל');
      setKey(key);
    }
    const res = await API('/update?key=' + encodeURIComponent(key));
    if (res && res.ok === false) {
      if ((res.error || '').toLowerCase().includes('unauthorized')) {
        setKey('');
        throw new Error('סיסמה שגויה');
      }
      // Already-running: don't error, just join the existing run
      if ((res.error || '') === 'already_running') {
        return { ok: true, joining: true };
      }
      throw new Error(res.error || 'שגיאה');
    }
    return res;
  };

  // Click handler
  updateBtn.addEventListener('click', async (ev) => {
    ev.preventDefault();
    if (updateBtn.disabled) return;  // guard against double-click

    try {
      updateBtn.disabled = true;
      resetOverlay();
      overlay.classList.add('show');

      // Step 1: Quick version check against Drive (no password needed)
      elStep.textContent = 'בודק גרסה...';
      elFile.textContent = '';
      elBar.style.width = '10%';
      const check = await API('/check').catch(() => null);

      if (!check || !check.ok) {
        showDone(false, 0, 'לא ניתן לבדוק גרסה — נסה שוב מאוחר יותר');
        return;
      }
      if (check.error || !check.remote) {
        // Couldn't reach Drive (rate limit / network) — surface honestly
        showDone(false, 0, 'לא ניתן לבדוק גרסה ב-Drive כעת — נסה שוב בעוד מספר דקות');
        return;
      }
      if (!check.needs_update) {
        // Already current — no password, no action
        showDone(true, 0, '');
        return;
      }

      // Step 2: A new version exists. Prompt for password and trigger update.
      const startTime = Date.now();
      showProgress('start', '', startTime);

      const upd = await postUpdate();
      // If the API returned "already_running", we just attach to the live run
      // (postUpdate returns { ok: true, joining: true } in that case).

      // Step 3: Poll status until finished (60 min safety)
      const t0 = Date.now();
      let lastTail = '';
      while (Date.now() - t0 < 60*60*1000) {
        const s = await getStatus();
        if (s.ok) {
          lastTail = s.tail || lastTail;
          if (!s.running) {
            const success = s.step === 'done';
            showProgress(s.step, lastTail, startTime);
            showDone(success, countFiles(lastTail),
              success ? '' : 'שלב: ' + (s.step || 'unknown'));
            break;
          }
          showProgress(s.step, lastTail, startTime);
        }
        await new Promise(r => setTimeout(r, 2000));
      }
    } catch (e) {
      // Cancelled password prompt = quiet exit; everything else = surface
      if ((e && e.message) === 'בוטל') {
        overlay.classList.remove('show');
      } else {
        showDone(false, 0, (e && e.message) || String(e));
      }
    } finally {
      updateBtn.disabled = false;
    }
  });
})();

  /* ===== מצב (קטגוריה) מה-URL ===== */
  function getMode() {
    const u = new URL(location.href);
    return (u.searchParams.get('mode') || 'porcelain').toLowerCase();
  }

  /* ===== טעינת assets/<mode>.js ===== */
  function loadProducts(mode) {
    return new Promise((resolve, reject) => {
      window.products = undefined;
      const old = document.getElementById('dyn-products'); if (old) old.remove();
      const s = document.createElement('script');
      s.id = 'dyn-products';
      s.src = `assets/${mode}.js?v=${Date.now()}`;
      s.onload = () => {
        if (Array.isArray(window.products)) {
          resolve(window.products);
        } else if (window.products && Array.isArray(window.products[mode])) {
          resolve(window.products[mode]);
        } else {
          reject(new Error('window.products missing'));
        }
      };
      s.onerror = () => reject(new Error('failed to load assets/'+mode+'.js'));
      document.head.appendChild(s);
    });
  }

  /* ===== עזרי נתיבים ===== */
  const isFull     = p => typeof p === 'string' && (p.startsWith('images/') || p.startsWith('/'));
  const baseName   = s => (s||'').split('/').pop();
  const ensureSlash= d => (typeof d === 'string' && !d.endsWith('/')) ? (d + '/') : d;

  function resolveMain(p) {
    if (p.main) return isFull(p.main) ? p.main : (p.path||'') + p.main;
    if (Array.isArray(p.images) && p.images.length) {
      const first = p.images[0];
      return isFull(first) ? first : (p.path||'') + first;
    }
    return '';
  }

  function resolveImages(p) {
    if (Array.isArray(p.images) && p.images.length) {
      return p.images.map(x => isFull(x) ? x : (p.path||'') + x);
    }
    const m = resolveMain(p);
    return m ? [m] : [];
  }

  function resolveThumbs(p, imgs) {
    if (Array.isArray(p.thumbnails) && p.thumbnails.length) return p.thumbnails.slice();
    if (p.thumbs && imgs.length) {
      const dir = ensureSlash(p.thumbs);
      return imgs.map(x => dir + baseName(x));
    }
    return imgs.slice();
  }

  /* ===== כרטיס מוצר בגריד ===== */
  function card(p) {
    const title  = p.title || p.name || '\u2014';
    const imgs   = resolveImages(p);
    if (!imgs.length) return null;

    const thumbs = resolveThumbs(p, imgs);
    const colors = Array.isArray(p.colors) ? p.colors : (p.color ? [p.color] : []);
    const main   = resolveMain(p);

    const el = document.createElement('div'); el.className='card';
    const m  = document.createElement('div'); m.className='media';

    const im = document.createElement('img');
    im.loading = 'lazy';
    im.decoding = 'async';
    im.src = thumbs[0] || imgs[0];
    im.onerror = () => { im.onerror = null; im.src = imgs[0]; };

    im.setAttribute('data-main',   main);
    im.setAttribute('data-images', imgs.join('|'));
    im.setAttribute('data-thumbs', thumbs.join('|'));
    im.setAttribute('data-title',  title);

    m.appendChild(im);

    const meta = document.createElement('div'); meta.className='meta';
    const t    = document.createElement('div'); t.className='title'; t.textContent = title;
    const sub  = document.createElement('div'); sub.className='sub';
    if (colors.length) sub.textContent = colors.join(', ');
    meta.append(t, sub);

    el.append(m, meta);
    return el;
  }

  /* ===== רנדר גריד ===== */
  function render(list) {
    const grid = byId('productGrid'); grid.innerHTML='';
    list.forEach(p => { const c = card(p); if (c) grid.appendChild(c); });
  }

  /* ===== אתחול ===== */
  async function boot() {
    try {
      const mode = getMode();
      const list = await loadProducts(mode);
      render(list);
    } catch (e) {
      byId('productGrid').innerHTML =
        '<div style="color:#f88;padding:12px;font:13px monospace">Error: '+(e.message||e)+'</div>';
    }
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();

  /* ===== Heartbeat — keeps Termux warm/active ===== */
  (function startHeartbeat(){
    var url = 'http://127.0.0.1:8765/status';
    function ping(){ try { fetch(url, {cache:'no-store'}).catch(function(){}); } catch(e){} }
    ping();
    setInterval(ping, 30000);
  })();

  /* ========= זום + רצועת סרט + סיבוב ========= */
  (function addZoomFeature() {
    const style = document.createElement('style');
    style.textContent = `
      #rbz-zoom-backdrop{position:fixed;inset:0;background:rgba(0,0,0,.86);
        display:none;flex-direction:column;align-items:center;justify-content:center;z-index:9999}
      #rbz-zoom-toolbar{position:absolute;top:10px;left:10px;right:10px;display:flex;gap:8px;justify-content:space-between}
      .rbz-btn{background:#222;color:#fff;border:1px solid #444;border-radius:8px;padding:.35rem .7rem;font-size:14px}
      #rbz-zoom-stage{display:flex;align-items:center;justify-content:center;flex:1;min-height:0;min-width:0;width:100%}
      #rbz-zoom-img{max-width:96vw;max-height:78vh;box-shadow:0 10px 40px rgba(0,0,0,.6);transition:transform .2s ease}
      #rbz-zoom-prev,#rbz-zoom-next{position:absolute;top:50%;transform:translateY(-50%);
        background:rgba(0,0,0,.35);border:1px solid #666;border-radius:10px;color:#fff;font-size:18px;padding:.45rem .7rem}
      #rbz-zoom-prev{left:10px} #rbz-zoom-next{right:10px}
      #rbz-strip{width:100%;max-width:98vw;display:flex;gap:8px;overflow-x:auto;padding:10px 14px 14px}
      #rbz-strip img{height:70px;aspect-ratio:16/9;object-fit:cover;border-radius:6px;opacity:.7;border:2px solid transparent;cursor:pointer}
      #rbz-strip img.active{opacity:1;border-color:#88aaff}
      #rbz-zoom-backdrop.show{display:flex}
    `;
    document.head.appendChild(style);

    const backdrop = document.createElement('div');
    backdrop.id = 'rbz-zoom-backdrop';
    backdrop.innerHTML = `
      <div id="rbz-zoom-toolbar">
        <div></div>
        <div>
          <button id="rbz-zoom-rotate" class="rbz-btn">\u05E1\u05D5\u05D1\u05D1</button>
          <button id="rbz-zoom-close"  class="rbz-btn">\u05E1\u05D2\u05D5\u05E8</button>
        </div>
      </div>
      <div id="rbz-zoom-stage">
        <button id="rbz-zoom-prev" aria-label="Prev">\u2039</button>
        <img id="rbz-zoom-img" alt="">
        <button id="rbz-zoom-next" aria-label="Next">\u203A</button>
      </div>
      <div id="rbz-strip"></div>
    `;
    document.body.appendChild(backdrop);

    const zoomImg = byId('rbz-zoom-img');
    const strip   = byId('rbz-strip');
    const btnPrev = byId('rbz-zoom-prev');
    const btnNext = byId('rbz-zoom-next');
    const btnClose= byId('rbz-zoom-close');
    const btnRot  = byId('rbz-zoom-rotate');

    let images = [];
    let thumbs = [];
    let idx    = 0;
    let rotated = 0;

    function show(i){
      if (!images.length) return;
      idx = (i+images.length)%images.length;
      zoomImg.src = images[idx];
      rotated = 0;
      zoomImg.style.transform = 'rotate(0deg)';
      [...strip.querySelectorAll('img')].forEach((t,ti)=>t.classList.toggle('active', ti===idx));
    }

    function buildStrip(){
      strip.innerHTML='';
      (thumbs.length?thumbs:images).forEach((src, i)=>{
        const t = document.createElement('img');
        t.src = src;
        t.onerror = () => { t.onerror = null; t.src = images[i] || src; };
        if (i===idx) t.classList.add('active');
        t.addEventListener('click', ()=>show(i));
        strip.appendChild(t);
      });
    }

    function openZoom(imgList, thumbList, startIndex=0){
      images = imgList||[];
      thumbs = (thumbList||[]).slice();
      show(startIndex||0);
      buildStrip();
      backdrop.classList.add('show');
    }
    function closeZoom(){ backdrop.classList.remove('show'); zoomImg.src=''; }

    btnPrev.addEventListener('click', ()=>show(idx-1));
    btnNext.addEventListener('click', ()=>show(idx+1));
    btnClose.addEventListener('click', closeZoom);
    btnRot.addEventListener('click', ()=>{
      rotated = (rotated+90)%360;
      zoomImg.style.transform = `rotate(${rotated}deg)`;
    });

    backdrop.addEventListener('click', e => { if (e.target===backdrop) closeZoom(); });
    document.addEventListener('keydown', e=>{
      if (!backdrop.classList.contains('show')) return;
      if (e.key==='Escape') closeZoom();
      else if (e.key==='ArrowLeft') show(idx-1);
      else if (e.key==='ArrowRight') show(idx+1);
      else if (e.key.toLowerCase()==='r') btnRot.click();
    });

    const grid = document.getElementById('productGrid') || document.body;
    function wire(root) {
      const imgs = root.querySelectorAll?.('img') || [];
      imgs.forEach(img => {
        if (img.dataset.rbzZoomWired) return;
        img.dataset.rbzZoomWired = '1';
        img.style.cursor = 'zoom-in';
        img.addEventListener('click', ev => {
          const imgList   = (img.getAttribute('data-images')||'').split('|').filter(Boolean);
          const thumbList = (img.getAttribute('data-thumbs')||'').split('|').filter(Boolean);
          const main      = img.getAttribute('data-main') || img.src;
          let start = 0;
          const at = imgList.indexOf(main);
          if (at>=0) start = at;
          openZoom(imgList.length?imgList:[main], thumbList, start);
          ev.stopPropagation();
        }, { passive:true });
      });
    }
    wire(grid);

    const mo = new MutationObserver(muts => {
      muts.forEach(m => m.addedNodes.forEach(n => {
        if (n.nodeType===1) wire(n.tagName==='IMG' ? n.parentElement||grid : n);
      }));
    });
    mo.observe(grid, { childList:true, subtree:true });
  })();
})();
