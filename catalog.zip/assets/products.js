/* Fully Kiosk readiness stub — keeps the "wait URL" check happy. */
window.__catalog_ready = true;
