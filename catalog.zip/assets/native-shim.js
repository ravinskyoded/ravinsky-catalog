/*
 * native-shim.js — גשר תאימות בין catalog-app.v17.js לאפליקציה Native.
 *
 * הקוד של הקטלוג נכתב במקור עבור Fully Kiosk + שרת מקומי על 127.0.0.1:8765.
 * ה-shim הזה מדמה את שתי השכבות האלה כדי שהקוד יעבוד ללא שינוי בתוך
 * WebView native, דרך הגשר AndroidApp.
 *
 * חייב להיטען לפני catalog-app.v17.js.
 */
(function () {
  'use strict';

  // ===== 0. גרסה נוכחית מתוך AndroidApp (סינכרוני, אמין) =====
  let CURRENT_VERSION = '';
  try {
    if (window.AndroidApp && typeof window.AndroidApp.getVersion === 'function') {
      CURRENT_VERSION = (window.AndroidApp.getVersion() || '').trim();
    }
  } catch (e) {
    console.warn('[native-shim] AndroidApp.getVersion failed:', e);
  }
  window.__APP_VERSION__ = CURRENT_VERSION;
  console.log('[native-shim] version =', CURRENT_VERSION || '(empty)');

  // ===== 1. מימוש window.fully (יציאה דרך הגשר, עם הגנת סיסמה) =====
  // קוד הקטלוג הקיים (catalog-app.v17.js) קורא ל-fully.exit() ללא בקשת סיסמה.
  // לכן ה-shim עצמו מבקש סיסמה לפני שמעביר ל-AndroidApp.
  // ברירת המחדל: '1234' (אותה סיסמה כמו של "עדכון"); ניתן לשנות ב-localStorage.
  if (typeof window.fully === 'undefined') {
    window.fully = {
      exit: function () {
        const storedKey = (localStorage.getItem('updateKey') || '1234').trim();
        const entered = prompt('סיסמה ליציאה:');
        if (entered === null) return;          // cancelled
        if (entered.trim() !== storedKey) {
          alert('סיסמה שגויה');
          return;
        }
        try {
          if (window.AndroidApp && typeof window.AndroidApp.closeApp === 'function') {
            window.AndroidApp.closeApp();
            return;
          }
        } catch (e) {}
        try { window.location.href = 'rbz://exit'; } catch (e) {}
      }
    };
  }

  // ===== 2. עזרי JSON =====
  function jsonResp(obj, status) {
    status = status || 200;
    return Promise.resolve(new Response(JSON.stringify(obj), {
      status: status,
      headers: { 'Content-Type': 'application/json' }
    }));
  }
  function parseJsonSafe(s, fallback) {
    try { return JSON.parse(s); } catch (e) { return fallback; }
  }

  // ===== 3. ניטור סיום עדכון — מעורר רענון WebView =====
  // כשעדכון מסתיים בהצלחה, נקרא ל-AndroidApp.reloadCatalog() כדי שה-WebView
  // יטען מחדש מ-internal storage עם התוכן החדש.
  let _statusPoller = null;
  function startStatusWatcher() {
    if (_statusPoller) return;
    _statusPoller = setInterval(function () {
      try {
        const raw = window.AndroidApp.getStatusJson();
        const st = parseJsonSafe(raw, {});
        if (!st.running) {
          clearInterval(_statusPoller);
          _statusPoller = null;
          if (st.last_result === 'success') {
            console.log('[native-shim] update succeeded — reloading');
            // עיכוב קטן כדי שה-UI יספיק להציג "✔ עודכן"
            setTimeout(function () {
              try { window.AndroidApp.reloadCatalog(); } catch (e) {}
            }, 1200);
          }
        }
      } catch (e) {
        clearInterval(_statusPoller);
        _statusPoller = null;
      }
    }, 800);
  }

  // ===== 4. יירוט fetch ל-127.0.0.1:8765 =====
  const origFetch = window.fetch ? window.fetch.bind(window) : null;

  window.fetch = function (input, init) {
    let url = '';
    try {
      url = (typeof input === 'string') ? input : (input && input.url) || '';
    } catch (e) { url = ''; }

    if (url.indexOf('127.0.0.1:8765') !== -1 || url.indexOf('localhost:8765') !== -1) {
      const path = url.split('8765')[1] || '';

      // /status — מצב עדכון נוכחי דרך הגשר
      if (path.indexOf('/status') === 0) {
        try {
          const raw = window.AndroidApp.getStatusJson();
          const st = parseJsonSafe(raw, { ok: true, running: false });
          return jsonResp(st);
        } catch (e) {
          return jsonResp({ ok: true, running: false });
        }
      }

      // /check — השוואת גרסאות local↔remote
      // משתמש ב-JS fetch (לא OkHttp) כדי לעקוף את ה-Cache של Java
      if (path.indexOf('/check') === 0) {
        const ghUrl = 'https://ravinskyoded.github.io/ravinsky-catalog/version.txt?t=' + Date.now();
        return (origFetch || Promise.reject.bind(Promise, new Error('no fetch')))(ghUrl, { cache: 'no-store' })
          .then(function(r) { return r.ok ? r.text() : Promise.reject(new Error('http ' + r.status)); })
          .then(function(remoteVer) {
            remoteVer = (remoteVer || '').trim();
            return jsonResp({
              ok: true,
              local: CURRENT_VERSION,
              remote: remoteVer,
              needs_update: !!(remoteVer && remoteVer !== CURRENT_VERSION)
            });
          })
          .catch(function() {
            // Fallback to Java bridge if network unavailable
            try {
              const raw = window.AndroidApp.checkUpdate();
              return jsonResp(parseJsonSafe(raw, { ok: false }));
            } catch (e) {
              return jsonResp({ ok: true, local: CURRENT_VERSION, remote: '', needs_update: false, error: 'bridge_error' });
            }
          });
      }

      // /update — הפעלת עדכון רקע
      if (path.indexOf('/update') === 0) {
        try {
          const raw = window.AndroidApp.startUpdate();
          const r = parseJsonSafe(raw, {});
          // מתחיל לעקוב אחרי סיום העדכון כדי לרענן את ה-WebView אוטומטית
          if (r.ok) startStatusWatcher();
          return jsonResp(r);
        } catch (e) {
          return jsonResp({ ok: false, error: 'bridge_error' }, 500);
        }
      }

      // /exit — סגירת האפליקציה
      if (path.indexOf('/exit') === 0) {
        try {
          if (window.AndroidApp && typeof window.AndroidApp.closeApp === 'function') {
            setTimeout(function () { window.AndroidApp.closeApp(); }, 100);
          }
        } catch (e) {}
        return jsonResp({ ok: true, exiting: true });
      }

      return jsonResp({ ok: false, error: 'not_found' }, 404);
    }

    if (origFetch) return origFetch(input, init);
    return Promise.reject(new Error('fetch unavailable'));
  };

  // ===== 5. AUTO-UPDATE — בדיקה תקופתית והורדה אוטומטית =====
  // הטבלטים בחנויות לא לוחצים "עדכון" באופן ידני. כדי שיתעדכנו אוטומטית:
  //   - אחרי 30 שניות מ-load: בודקים פעם ראשונה (חוסך תזמון boot race)
  //   - כל שעה: בודקים שוב
  //   - אם יש עדכון: מורידים בשקט, ברקע
  //   - אחרי הורדה: ה-statusWatcher הקיים מבצע reloadCatalog()
  //
  // ניתן לבטל בעזרת: localStorage.setItem('autoUpdate', 'off')
  const AUTO_CHECK_INTERVAL_MS = 10 * 60 * 1000;    // כל 10 דקות (במקום שעה)
  const AUTO_CHECK_INITIAL_MS  = 30 * 1000;          // 30 שניות אחרי טעינה

  function autoCheckAndUpdate() {
    // אם המשתמש כיבה את ה-auto-update — מדלגים
    if ((localStorage.getItem('autoUpdate') || 'on').toLowerCase() === 'off') return;
    // אם עדכון כבר רץ — מדלגים
    try {
      const stRaw = window.AndroidApp && window.AndroidApp.getStatusJson();
      const st = parseJsonSafe(stRaw, {});
      if (st && st.running) return;
    } catch (e) { return; }

    // בדיקת גרסה ישירות דרך JS fetch (עוקף את OkHttp cache של Java)
    const ghUrl = 'https://ravinskyoded.github.io/ravinsky-catalog/version.txt?t=' + Date.now();
    (origFetch || window.fetch)(ghUrl, { cache: 'no-store' })
      .then(function(r) { return r.text(); })
      .then(function(remoteVer) {
        remoteVer = (remoteVer || '').trim();
        if (!remoteVer || remoteVer === CURRENT_VERSION) return;

        console.log('[auto-update] new version:', remoteVer, '(local:', CURRENT_VERSION, ') — starting silent download');
        try {
          const upRaw = window.AndroidApp.startUpdate();
          const up = parseJsonSafe(upRaw, {});
          if (up && up.ok) startStatusWatcher();
        } catch (e) {
          console.warn('[auto-update] startUpdate failed:', e);
        }
      })
      .catch(function(e) {
        console.warn('[auto-update] version check failed:', e);
      });
  }

  // הפעלה
  setTimeout(autoCheckAndUpdate, AUTO_CHECK_INITIAL_MS);
  setInterval(autoCheckAndUpdate, AUTO_CHECK_INTERVAL_MS);
  console.log('[native-shim] auto-update scheduled (every', AUTO_CHECK_INTERVAL_MS/60000, 'min, JS fetch bypass)');

  window.__NATIVE_SHIM__ = true;
  console.log('[native-shim] loaded — Update v3 (auto-update enabled)');
})();
