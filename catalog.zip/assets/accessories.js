window.products = [
  {
    "name": "kir_decorative_ankara",
    "path": "images/products/accessories/kir_decorative_ankara/",
    "main": "2025-10-08_at_11.42.21_(1).jpeg",
    "images": [
      "2025-10-08_at_11.42.21_(1).jpeg",
      "2025-10-08_at_11.42.22.jpeg",
      "A_Katary__White.jpg",
      "A_kir_decorativ_ankara.jpeg",
      "Katary__White_-1.png",
      "Katary__White-2.png",
      "kir_decorative_ankara_main.jpg",
      "koten_white.JPG"
    ],
    "thumbnails": [
      "thumbnails/2025-10-08_at_11.42.21_(1).jpeg",
      "thumbnails/2025-10-08_at_11.42.22.jpeg",
      "thumbnails/A_Katary__White.jpg",
      "thumbnails/A_kir_decorativ_ankara.jpeg",
      "thumbnails/Katary__White_-1.png",
      "thumbnails/Katary__White-2.png",
      "thumbnails/kir_decorative_ankara_main.jpg",
      "thumbnails/koten_white.JPG"
    ]
  },
  {
    "name": "lahzan_niagara_integrali",
    "path": "images/products/accessories/lahzan_niagara_integrali/",
    "main": "A_lahzniagara.jpeg",
    "images": [
      "A_lahzniagara.jpeg"
    ],
    "thumbnails": [
      "thumbnails/A_lahzniagara.jpeg"
    ]
  },
  {
    "name": "sheka_hashmal_integrali",
    "path": "images/products/accessories/sheka_hashmal_integrali/",
    "main": "0-08_at_16.19.13_(1).jpeg",
    "images": [
      "0-08_at_16.19.13_(1).jpeg",
      "-10-08_at_16.25.22.jpeg",
      "2025-10-08_at_16.19.12.jpeg",
      "2025-10-08_at_16.19.13.jpeg",
      "5-10-08_at_16.20.01.jpeg",
      "A_sheka_integrali.jpeg",
      "sheka_hashmal_integrali_01.jpg",
      "sheka_hashmal_integrali_02.jpg",
      "sheka_hashmal_integrali_03.jpg",
      "sheka_hashmal_integrali_04.jpg",
      "sheka_hashmal_integrali_05.jpg",
      "sheka_hashmal_integrali_main.jpg"
    ],
    "thumbnails": [
      "thumbnails/0-08_at_16.19.13_(1).jpeg",
      "thumbnails/-10-08_at_16.25.22.jpeg",
      "thumbnails/2025-10-08_at_16.19.12.jpeg",
      "thumbnails/2025-10-08_at_16.19.13.jpeg",
      "thumbnails/5-10-08_at_16.20.01.jpeg",
      "thumbnails/A_sheka_integrali.jpeg",
      "thumbnails/sheka_hashmal_integrali_01.jpg",
      "thumbnails/sheka_hashmal_integrali_02.jpg",
      "thumbnails/sheka_hashmal_integrali_03.jpg",
      "thumbnails/sheka_hashmal_integrali_04.jpg",
      "thumbnails/sheka_hashmal_integrali_05.jpg",
      "thumbnails/sheka_hashmal_integrali_main.jpg"
    ]
  }
];
