window.products = [
  {
    "name": "adria",
    "path": "images/products/porcelain/adria/",
    "main": "adria_01.jpg",
    "images": [
      "adria_01.jpg",
      "adria_03.jpg",
      "adria_05.jpg",
      "adria_06.jpg",
      "adria_07.jpg",
      "adria_08.jpg",
      "adria_09.jpg",
      "adria_10.jpg",
      "adria_11.jpg",
      "adria_12.jpg"
    ],
    "thumbnails": [
      "thumbnails/adria_01.jpg",
      "thumbnails/adria_03.jpg",
      "thumbnails/adria_05.jpg",
      "thumbnails/adria_06.jpg",
      "thumbnails/adria_07.jpg",
      "thumbnails/adria_08.jpg",
      "thumbnails/adria_09.jpg",
      "thumbnails/adria_10.jpg",
      "thumbnails/adria_11.jpg",
      "thumbnails/adria_12.jpg"
    ]
  },
  {
    "name": "ankara_vain",
    "path": "images/products/porcelain/ankara_vain/",
    "main": "ankara_vain_main.jpg",
    "images": [
      "ankara 4.JPG",
      "ankara 5.JPG",
      "ankara 6.JPG",
      "ankara_4.JPG",
      "ankara_5.JPG",
      "ankara_6.JPG",
      "ankara_8_(10).jpg",
      "ankara_8_(11).jpg",
      "ankara_8_(12).jpg",
      "ankara_8_(13).jpg",
      "ankara_8_(14).jpg",
      "ankara_8_(2).jpg",
      "ankara_8_(3).jpg",
      "ankara_8_(4).jpg",
      "ankara_8_(5).jpg",
      "ankara_8_(6).jpg",
      "ankara_8_(7).jpg",
      "ankara_8_(8).jpg",
      "ankara_8_(9).jpg",
      "Ankara_Space2.jpg",
      "ankara_vain_01.jpg",
      "ankara_vain_04.jpg",
      "ankara_vain_05.jpg",
      "ankara_vain_06.jpg",
      "ankara_vain_07.jpg",
      "ankara_vain_08.jpg",
      "ankara_vain_09.jpg",
      "ankara_vain_10.jpg",
      "ankara_vain_11.jpg",
      "ankara_vain_12.jpg",
      "ankara_vain_13.jpg",
      "ankara_vain_15.jpg",
      "ankara_vain_17.jpg",
      "ankara_vain_18.jpg",
      "ankara_vain_20.jpg",
      "ankara_vain_22.jpg",
      "ankara_vain_23.jpg",
      "ankara_vain_25.jpg",
      "ankara_vain_26.jpg",
      "ankara_vain_27.jpg",
      "ankara_vain_28.jpg",
      "ankara_vain_29.jpg",
      "ankara_vain_main.jpg",
      "ankara7.JPG"
    ],
    "thumbnails": [
      "thumbnails/ankara 4.JPG",
      "thumbnails/ankara 5.JPG",
      "thumbnails/ankara 6.JPG",
      "thumbnails/ankara_4.JPG",
      "thumbnails/ankara_5.JPG",
      "thumbnails/ankara_6.JPG",
      "thumbnails/ankara_8_(10).jpg",
      "thumbnails/ankara_8_(11).jpg",
      "thumbnails/ankara_8_(12).jpg",
      "thumbnails/ankara_8_(13).jpg",
      "thumbnails/ankara_8_(14).jpg",
      "thumbnails/ankara_8_(2).jpg",
      "thumbnails/ankara_8_(3).jpg",
      "thumbnails/ankara_8_(4).jpg",
      "thumbnails/ankara_8_(5).jpg",
      "thumbnails/ankara_8_(6).jpg",
      "thumbnails/ankara_8_(7).jpg",
      "thumbnails/ankara_8_(8).jpg",
      "thumbnails/ankara_8_(9).jpg",
      "thumbnails/Ankara_Space2.jpg",
      "thumbnails/ankara_vain_01.jpg",
      "thumbnails/ankara_vain_04.jpg",
      "thumbnails/ankara_vain_05.jpg",
      "thumbnails/ankara_vain_06.jpg",
      "thumbnails/ankara_vain_07.jpg",
      "thumbnails/ankara_vain_08.jpg",
      "thumbnails/ankara_vain_09.jpg",
      "thumbnails/ankara_vain_10.jpg",
      "thumbnails/ankara_vain_11.jpg",
      "thumbnails/ankara_vain_12.jpg",
      "thumbnails/ankara_vain_13.jpg",
      "thumbnails/ankara_vain_15.jpg",
      "thumbnails/ankara_vain_17.jpg",
      "thumbnails/ankara_vain_18.jpg",
      "thumbnails/ankara_vain_20.jpg",
      "thumbnails/ankara_vain_22.jpg",
      "thumbnails/ankara_vain_23.jpg",
      "thumbnails/ankara_vain_25.jpg",
      "thumbnails/ankara_vain_26.jpg",
      "thumbnails/ankara_vain_27.jpg",
      "thumbnails/ankara_vain_28.jpg",
      "thumbnails/ankara_vain_29.jpg",
      "thumbnails/ankara_vain_main.jpg",
      "thumbnails/ankara7.JPG"
    ]
  },
  {
    "name": "berka_grey",
    "path": "images/products/porcelain/berka_grey/",
    "main": "berka_grey_10.jpg",
    "images": [
      "berka_grey_01.jpg",
      "berka_grey_02.jpg",
      "berka_grey_03.jpg",
      "berka_grey_04.jpg",
      "berka_grey_05.jpg",
      "berka_grey_06.jpg",
      "berka_grey_07.jpg",
      "berka_grey_08.jpg",
      "berka_grey_09.jpg",
      "berka_grey_10.jpg"
    ],
    "thumbnails": [
      "thumbnails/berka_grey_01.jpg",
      "thumbnails/berka_grey_02.jpg",
      "thumbnails/berka_grey_03.jpg",
      "thumbnails/berka_grey_04.jpg",
      "thumbnails/berka_grey_05.jpg",
      "thumbnails/berka_grey_06.jpg",
      "thumbnails/berka_grey_07.jpg",
      "thumbnails/berka_grey_08.jpg",
      "thumbnails/berka_grey_09.jpg",
      "thumbnails/berka_grey_10.jpg"
    ]
  },
  {
    "name": "brown_positano",
    "path": "images/products/porcelain/brown_positano/",
    "main": "brown_positano_main.jpg",
    "images": [
      "Brown Positano Space1.jpg",
      "Brown Positano Space10.png",
      "Brown Positano Space12.png",
      "Brown Positano Space14.png",
      "Brown Positano Space4.png",
      "Brown Positano Space5.png",
      "Brown Positano Space7.png",
      "brown_positano_01.jpg",
      "brown_positano_02.jpg",
      "brown_positano_04.jpg",
      "brown_positano_05.jpg",
      "brown_positano_06.jpg",
      "brown_positano_07.jpg",
      "brown_positano_08.jpg",
      "brown_positano_12.jpg",
      "brown_positano_13.jpg",
      "brown_positano_14.jpg",
      "brown_positano_15.jpg",
      "brown_positano_16.jpg",
      "brown_positano_17.jpg",
      "brown_positano_18.jpg",
      "brown_positano_19.jpg",
      "brown_positano_20.jpg",
      "brown_positano_21.jpg",
      "brown_positano_22.jpg",
      "brown_positano_main.jpg",
      "Brown_Positano_Space1.jpg",
      "Brown_Positano_Space10.png",
      "Brown_Positano_Space11.png",
      "Brown_Positano_Space12.png",
      "Brown_Positano_Space13.png",
      "Brown_Positano_Space14.png",
      "Brown_Positano_Space3.png",
      "Brown_Positano_Space4.png",
      "Brown_Positano_Space5.png",
      "Brown_Positano_Space6.png",
      "Brown_Positano_Space7.png",
      "Brown_Positano_Space8.png",
      "Brown_Positano_Space9.png",
      "WhatsApp_Image_2026-02-01_at_10.47.23.jpeg",
      "WhatsApp_Image_2026-02-01_at_10.47.24.jpeg",
      "WhatsApp_Image_2026-02-01_at_10.47.24_(1).jpeg",
      "WhatsApp_Image_2026-02-01_at_10.47.45.jpeg",
      "WhatsApp_Image_2026-02-01_at_10.47.46.jpeg",
      "WhatsApp_Image_2026-02-01_at_10.47.46_(1).jpeg"
    ],
    "thumbnails": [
      "thumbnails/Brown Positano Space1.jpg",
      "thumbnails/Brown Positano Space10.png",
      "thumbnails/Brown Positano Space12.png",
      "thumbnails/Brown Positano Space14.png",
      "thumbnails/Brown Positano Space4.png",
      "thumbnails/Brown Positano Space5.png",
      "thumbnails/Brown Positano Space7.png",
      "thumbnails/brown_positano_01.jpg",
      "thumbnails/brown_positano_02.jpg",
      "thumbnails/brown_positano_04.jpg",
      "thumbnails/brown_positano_05.jpg",
      "thumbnails/brown_positano_06.jpg",
      "thumbnails/brown_positano_07.jpg",
      "thumbnails/brown_positano_08.jpg",
      "thumbnails/brown_positano_12.jpg",
      "thumbnails/brown_positano_13.jpg",
      "thumbnails/brown_positano_14.jpg",
      "thumbnails/brown_positano_15.jpg",
      "thumbnails/brown_positano_16.jpg",
      "thumbnails/brown_positano_17.jpg",
      "thumbnails/brown_positano_18.jpg",
      "thumbnails/brown_positano_19.jpg",
      "thumbnails/brown_positano_20.jpg",
      "thumbnails/brown_positano_21.jpg",
      "thumbnails/brown_positano_22.jpg",
      "thumbnails/brown_positano_main.jpg",
      "thumbnails/Brown_Positano_Space1.jpg",
      "thumbnails/Brown_Positano_Space10.png",
      "thumbnails/Brown_Positano_Space11.png",
      "thumbnails/Brown_Positano_Space12.png",
      "thumbnails/Brown_Positano_Space13.png",
      "thumbnails/Brown_Positano_Space14.png",
      "thumbnails/Brown_Positano_Space3.png",
      "thumbnails/Brown_Positano_Space4.png",
      "thumbnails/Brown_Positano_Space5.png",
      "thumbnails/Brown_Positano_Space6.png",
      "thumbnails/Brown_Positano_Space7.png",
      "thumbnails/Brown_Positano_Space8.png",
      "thumbnails/Brown_Positano_Space9.png",
      "thumbnails/WhatsApp_Image_2026-02-01_at_10.47.23.jpeg",
      "thumbnails/WhatsApp_Image_2026-02-01_at_10.47.24.jpeg",
      "thumbnails/WhatsApp_Image_2026-02-01_at_10.47.24_(1).jpeg",
      "thumbnails/WhatsApp_Image_2026-02-01_at_10.47.45.jpeg",
      "thumbnails/WhatsApp_Image_2026-02-01_at_10.47.46.jpeg",
      "thumbnails/WhatsApp_Image_2026-02-01_at_10.47.46_(1).jpeg"
    ]
  },
  {
    "name": "calacata_burgini",
    "path": "images/products/porcelain/calacata_burgini/",
    "main": "calacata_burgini_main.jpg",
    "images": [
      "A_calacata_burgini.jpg",
      "calacata_burgini_main.jpg"
    ],
    "thumbnails": [
      "thumbnails/A_calacata_burgini.jpg",
      "thumbnails/calacata_burgini_main.jpg"
    ]
  },
  {
    "name": "calacata_king",
    "path": "images/products/porcelain/calacata_king/",
    "main": "calacata_king_main.jpg",
    "images": [
      "calacata_king_01.jpg",
      "calacata_king_02.jpg",
      "calacata_king_main.jpg"
    ],
    "thumbnails": [
      "thumbnails/calacata_king_01.jpg",
      "thumbnails/calacata_king_02.jpg",
      "thumbnails/calacata_king_main.jpg"
    ]
  },
  {
    "name": "calacatta_royal",
    "path": "images/products/porcelain/calacatta_royal/",
    "main": "calacatta_royal_02.jpg",
    "images": [
      "calacatta_royal_02.jpg",
      "calacatta_royal_03.jpg",
      "calacatta_royal_04.jpg",
      "calacatta_royal_05.jpg",
      "calacatta_royal_06.jpg",
      "calacatta_royal_07.jpg",
      "calacatta_royal_08.jpg",
      "calacatta_royal_09.jpg",
      "calacatta_royal_11.jpg"
    ],
    "thumbnails": [
      "thumbnails/calacatta_royal_02.jpg",
      "thumbnails/calacatta_royal_03.jpg",
      "thumbnails/calacatta_royal_04.jpg",
      "thumbnails/calacatta_royal_05.jpg",
      "thumbnails/calacatta_royal_06.jpg",
      "thumbnails/calacatta_royal_07.jpg",
      "thumbnails/calacatta_royal_08.jpg",
      "thumbnails/calacatta_royal_09.jpg",
      "thumbnails/calacatta_royal_11.jpg"
    ]
  },
  {
    "name": "camuoflage",
    "path": "images/products/porcelain/camuoflage/",
    "main": "camuoflage_01.jpg",
    "images": [
      "Camouflage Kitchen (1).jpg",
      "Camouflage Kitchen (2).jpg",
      "Camouflage Kitchen (3).jpg",
      "Camouflage Kitchen (5).jpg",
      "Camouflage Kitchen (6).jpg",
      "Camouflage Kitchen (7).jpg",
      "Camouflage Kitchen (8).jpg",
      "Camouflage_Kitchen_(1).jpg",
      "Camouflage_Kitchen_(2).jpg",
      "Camouflage_Kitchen_(3).jpg",
      "Camouflage_Kitchen_(5).jpg",
      "Camouflage_Kitchen_(6).jpg",
      "Camouflage_Kitchen_(7).jpg",
      "Camouflage_Kitchen_(8).jpg",
      "camuoflage_01.jpg",
      "camuoflage_02.jpg",
      "camuoflage_05.jpg",
      "camuoflage_06.jpg",
      "camuoflage_07.jpg",
      "camuoflage_09.jpg"
    ],
    "thumbnails": [
      "thumbnails/Camouflage Kitchen (1).jpg",
      "thumbnails/Camouflage Kitchen (2).jpg",
      "thumbnails/Camouflage Kitchen (3).jpg",
      "thumbnails/Camouflage Kitchen (5).jpg",
      "thumbnails/Camouflage Kitchen (6).jpg",
      "thumbnails/Camouflage Kitchen (7).jpg",
      "thumbnails/Camouflage Kitchen (8).jpg",
      "thumbnails/Camouflage_Kitchen_(1).jpg",
      "thumbnails/Camouflage_Kitchen_(2).jpg",
      "thumbnails/Camouflage_Kitchen_(3).jpg",
      "thumbnails/Camouflage_Kitchen_(5).jpg",
      "thumbnails/Camouflage_Kitchen_(6).jpg",
      "thumbnails/Camouflage_Kitchen_(7).jpg",
      "thumbnails/Camouflage_Kitchen_(8).jpg",
      "thumbnails/camuoflage_01.jpg",
      "thumbnails/camuoflage_02.jpg",
      "thumbnails/camuoflage_05.jpg",
      "thumbnails/camuoflage_06.jpg",
      "thumbnails/camuoflage_07.jpg",
      "thumbnails/camuoflage_09.jpg"
    ]
  },
  {
    "name": "camus_white",
    "path": "images/products/porcelain/camus_white/",
    "main": "camus_white_12.jpg",
    "images": [
      "camus_white_01.jpg",
      "camus_white_02.jpg",
      "camus_white_03.jpg",
      "camus_white_04.jpg",
      "camus_white_05.jpg",
      "camus_white_06.jpg",
      "camus_white_08.jpg",
      "camus_white_09.jpg",
      "camus_white_11.jpg",
      "camus_white_12.jpg",
      "camus_white_14.jpg"
    ],
    "thumbnails": [
      "thumbnails/camus_white_01.jpg",
      "thumbnails/camus_white_02.jpg",
      "thumbnails/camus_white_03.jpg",
      "thumbnails/camus_white_04.jpg",
      "thumbnails/camus_white_05.jpg",
      "thumbnails/camus_white_06.jpg",
      "thumbnails/camus_white_08.jpg",
      "thumbnails/camus_white_09.jpg",
      "thumbnails/camus_white_11.jpg",
      "thumbnails/camus_white_12.jpg",
      "thumbnails/camus_white_14.jpg"
    ]
  },
  {
    "name": "diano",
    "path": "images/products/porcelain/diano/",
    "main": "diano_01.jpg",
    "images": [
      "diano_01.jpg",
      "diano_02.jpg"
    ],
    "thumbnails": [
      "thumbnails/diano_01.jpg",
      "thumbnails/diano_02.jpg"
    ]
  },
  {
    "name": "embrace_forest",
    "path": "images/products/porcelain/embrace_forest/",
    "main": "1.png",
    "images": [
      "1.png",
      "2.png",
      "4.png",
      "5.png",
      "A_Embrace_Forest.jpg"
    ],
    "thumbnails": [
      "thumbnails/1.png",
      "thumbnails/2.png",
      "thumbnails/4.png",
      "thumbnails/5.png",
      "thumbnails/A_Embrace_Forest.jpg"
    ]
  },
  {
    "name": "emperior_onix",
    "path": "images/products/porcelain/emperior_onix/",
    "main": "emperior_onix_04.jpg",
    "images": [
      "emperior onyx 2.jpeg",
      "emperior_onix_01.jpg",
      "emperior_onix_04.jpg",
      "emperior_onix_05.jpg",
      "emperior_onix_06.jpg",
      "emperior_onix_08.jpg",
      "emperior_onix_09.jpg",
      "emperior_onix_10.jpg",
      "emperior_onix_11.jpg",
      "emperior_onyx_2.jpeg"
    ],
    "thumbnails": [
      "thumbnails/emperior onyx 2.jpeg",
      "thumbnails/emperior_onix_01.jpg",
      "thumbnails/emperior_onix_04.jpg",
      "thumbnails/emperior_onix_05.jpg",
      "thumbnails/emperior_onix_06.jpg",
      "thumbnails/emperior_onix_08.jpg",
      "thumbnails/emperior_onix_09.jpg",
      "thumbnails/emperior_onix_10.jpg",
      "thumbnails/emperior_onix_11.jpg",
      "thumbnails/emperior_onyx_2.jpeg"
    ]
  },
  {
    "name": "galaxy_beige",
    "path": "images/products/porcelain/galaxy_beige/",
    "main": "A_galaxy beige.jpg",
    "images": [
      "A_galaxy beige.jpg",
      "A_galaxy_beige.jpg",
      "Galaxy beige.JPG",
      "Galaxy_beige.JPG"
    ],
    "thumbnails": [
      "thumbnails/A_galaxy beige.jpg",
      "thumbnails/A_galaxy_beige.jpg",
      "thumbnails/Galaxy beige.JPG",
      "thumbnails/Galaxy_beige.JPG"
    ]
  },
  {
    "name": "galaxy_white",
    "path": "images/products/porcelain/galaxy_white/",
    "main": "galaxy_white_main.jpg",
    "images": [
      "dsc04240.jpg",
      "dsc04247.jpg",
      "dsc04331.jpg",
      "dsc04341.jpg",
      "dsc04385.jpg",
      "dsc04397.jpg",
      "dsc04407.jpg",
      "dsc04415.jpg",
      "dsc04419.jpg",
      "dsc04419-2.jpg",
      "dsc04422.jpg",
      "dsc04441.jpg",
      "dsc04493.jpg",
      "galaxy white.png",
      "galaxy_white.png",
      "galaxy_white_05.jpg",
      "galaxy_white_06.jpg",
      "galaxy_white_11.jpg",
      "galaxy_white_12.jpg",
      "galaxy_white_16.jpg",
      "galaxy_white_main.jpg"
    ],
    "thumbnails": [
      "thumbnails/dsc04240.jpg",
      "thumbnails/dsc04247.jpg",
      "thumbnails/dsc04331.jpg",
      "thumbnails/dsc04341.jpg",
      "thumbnails/dsc04385.jpg",
      "thumbnails/dsc04397.jpg",
      "thumbnails/dsc04407.jpg",
      "thumbnails/dsc04415.jpg",
      "thumbnails/dsc04419.jpg",
      "thumbnails/dsc04419-2.jpg",
      "thumbnails/dsc04422.jpg",
      "thumbnails/dsc04441.jpg",
      "thumbnails/dsc04493.jpg",
      "thumbnails/galaxy white.png",
      "thumbnails/galaxy_white.png",
      "thumbnails/galaxy_white_05.jpg",
      "thumbnails/galaxy_white_06.jpg",
      "thumbnails/galaxy_white_11.jpg",
      "thumbnails/galaxy_white_12.jpg",
      "thumbnails/galaxy_white_16.jpg",
      "thumbnails/galaxy_white_main.jpg"
    ]
  },
  {
    "name": "gamma_grey",
    "path": "images/products/porcelain/gamma_grey/",
    "main": "gamma_grey_main.jpg",
    "images": [
      "gamma_grey_main.jpg"
    ],
    "thumbnails": [
      "thumbnails/gamma_grey_main.jpg"
    ]
  },
  {
    "name": "golden_glow",
    "path": "images/products/porcelain/golden_glow/",
    "main": "golden_glow_main.jpg",
    "images": [
      "golden_glow_03.jpg",
      "golden_glow_04.jpg",
      "golden_glow_05.jpg",
      "golden_glow_06.jpg",
      "golden_glow_08.jpg",
      "golden_glow_main.jpg"
    ],
    "thumbnails": [
      "thumbnails/golden_glow_03.jpg",
      "thumbnails/golden_glow_04.jpg",
      "thumbnails/golden_glow_05.jpg",
      "thumbnails/golden_glow_06.jpg",
      "thumbnails/golden_glow_08.jpg",
      "thumbnails/golden_glow_main.jpg"
    ]
  },
  {
    "name": "infinity_travertino",
    "path": "images/products/porcelain/infinity_travertino/",
    "main": "infinity_travertino_main.jpg",
    "images": [
      "dannymaron40-48.jpg",
      "dannymaron40-58.jpg",
      "dannymaron50-91.jpg",
      "infinity(3).jpg",
      "infinity_(2).jpg",
      "infinity_(7).jpg",
      "INFINITY__(8).jpg",
      "infinity_travertino_01.jpg",
      "infinity_travertino_02.jpg",
      "infinity_travertino_07.jpg",
      "infinity_travertino_09.jpg",
      "infinity_travertino_11.jpg",
      "infinity_travertino_14.jpg",
      "infinity_travertino_main.jpg",
      "WhatsApp_Image_2026-03-08_at_09.34.51.jpeg",
      "WhatsApp_Image_2026-03-08_at_09.34.53.jpeg"
    ],
    "thumbnails": [
      "thumbnails/dannymaron40-48.jpg",
      "thumbnails/dannymaron40-58.jpg",
      "thumbnails/dannymaron50-91.jpg",
      "thumbnails/infinity(3).jpg",
      "thumbnails/infinity_(2).jpg",
      "thumbnails/infinity_(7).jpg",
      "thumbnails/INFINITY__(8).jpg",
      "thumbnails/infinity_travertino_01.jpg",
      "thumbnails/infinity_travertino_02.jpg",
      "thumbnails/infinity_travertino_07.jpg",
      "thumbnails/infinity_travertino_09.jpg",
      "thumbnails/infinity_travertino_11.jpg",
      "thumbnails/infinity_travertino_14.jpg",
      "thumbnails/infinity_travertino_main.jpg",
      "thumbnails/WhatsApp_Image_2026-03-08_at_09.34.51.jpeg",
      "thumbnails/WhatsApp_Image_2026-03-08_at_09.34.53.jpeg"
    ]
  },
  {
    "name": "katary_white",
    "path": "images/products/porcelain/katary_white/",
    "main": "A_Katary__White.jpg",
    "images": [
      "A_Katary__White.jpg",
      "Katary__White_-1.png",
      "Katary__White-2.png",
      "katary_white_01.jpg",
      "katary_white_01.png",
      "katary_white_02.png",
      "katary_white_03.png",
      "katary_white_04.png",
      "katary_white_05.png",
      "katary_white_06.png",
      "katary_white_07.png"
    ],
    "thumbnails": [
      "thumbnails/A_Katary__White.jpg",
      "thumbnails/Katary__White_-1.png",
      "thumbnails/Katary__White-2.png",
      "thumbnails/katary_white_01.jpg",
      "thumbnails/katary_white_01.png",
      "thumbnails/katary_white_02.png",
      "thumbnails/katary_white_03.png",
      "thumbnails/katary_white_04.png",
      "thumbnails/katary_white_05.png",
      "thumbnails/katary_white_06.png",
      "thumbnails/katary_white_07.png"
    ]
  },
  {
    "name": "kotan_white",
    "path": "images/products/porcelain/kotan_white/",
    "main": "kotan_white_01.jpg",
    "images": [
      "kotan_white_01.jpg",
      "kotan_white_02.jpg",
      "kotan_white_main.jpg",
      "koten_white.JPG"
    ],
    "thumbnails": [
      "thumbnails/kotan_white_01.jpg",
      "thumbnails/kotan_white_02.jpg",
      "thumbnails/kotan_white_main.jpg",
      "thumbnails/koten_white.JPG"
    ]
  },
  {
    "name": "limestone",
    "path": "images/products/porcelain/limestone/",
    "main": "A_Limestone.jpg",
    "images": [
      "A_Limestone.jpg",
      "limestone_01.jpg",
      "limestone_04.jpg",
      "Limestone_Cream_Space1.jpg",
      "Limestone_Cream_Space2.jpg",
      "Limestone_Cream_Space3.jpg",
      "WhatsApp_Image_2026-05-24_at_10.20.40.jpeg",
      "WhatsApp_Image_2026-05-24_at_10.21.08.jpeg",
      "WhatsApp_Image_2026-05-24_at_10.21.12.jpeg"
    ],
    "thumbnails": [
      "thumbnails/A_Limestone.jpg",
      "thumbnails/limestone_01.jpg",
      "thumbnails/limestone_04.jpg",
      "thumbnails/Limestone_Cream_Space1.jpg",
      "thumbnails/Limestone_Cream_Space2.jpg",
      "thumbnails/Limestone_Cream_Space3.jpg",
      "thumbnails/WhatsApp_Image_2026-05-24_at_10.20.40.jpeg",
      "thumbnails/WhatsApp_Image_2026-05-24_at_10.21.08.jpeg",
      "thumbnails/WhatsApp_Image_2026-05-24_at_10.21.12.jpeg"
    ]
  },
  {
    "name": "limestone_grigio",
    "path": "images/products/porcelain/limestone_grigio/",
    "main": "limestone_grigio_07.jpg",
    "images": [
      "A_Limestone_Grigio.jpg",
      "limestone_grigio_01.jpg",
      "limestone_grigio_02.jpg",
      "limestone_grigio_03.jpg",
      "limestone_grigio_04.jpg",
      "limestone_grigio_05.jpg",
      "limestone_grigio_06.jpg",
      "limestone_grigio_07.jpg",
      "Limestone_Grigio_Space1.jpg",
      "Limestone_Grigio_Space2.jpg",
      "Limestone_Grigio_Space3.jpg",
      "Limestone_Grigio_Space4.jpg",
      "Limestone_Grigio_Space5.jpg",
      "Limestone_Grigio_Space7.jpg"
    ],
    "thumbnails": [
      "thumbnails/A_Limestone_Grigio.jpg",
      "thumbnails/limestone_grigio_01.jpg",
      "thumbnails/limestone_grigio_02.jpg",
      "thumbnails/limestone_grigio_03.jpg",
      "thumbnails/limestone_grigio_04.jpg",
      "thumbnails/limestone_grigio_05.jpg",
      "thumbnails/limestone_grigio_06.jpg",
      "thumbnails/limestone_grigio_07.jpg",
      "thumbnails/Limestone_Grigio_Space1.jpg",
      "thumbnails/Limestone_Grigio_Space2.jpg",
      "thumbnails/Limestone_Grigio_Space3.jpg",
      "thumbnails/Limestone_Grigio_Space4.jpg",
      "thumbnails/Limestone_Grigio_Space5.jpg",
      "thumbnails/Limestone_Grigio_Space7.jpg"
    ]
  },
  {
    "name": "luxure_white",
    "path": "images/products/porcelain/luxure_white/",
    "main": "luxure_white_01.jpg",
    "images": [
      "luxure_white_01.jpg",
      "luxure_white_02.jpg",
      "luxure_white_03.jpg",
      "luxure_white_04.jpg",
      "luxure_white_08.jpg",
      "luxure_white_09.jpg",
      "luxure_white_10.jpg",
      "luxure_white_11.jpg",
      "luxure_white_12.jpg"
    ],
    "thumbnails": [
      "thumbnails/luxure_white_01.jpg",
      "thumbnails/luxure_white_02.jpg",
      "thumbnails/luxure_white_03.jpg",
      "thumbnails/luxure_white_04.jpg",
      "thumbnails/luxure_white_08.jpg",
      "thumbnails/luxure_white_09.jpg",
      "thumbnails/luxure_white_10.jpg",
      "thumbnails/luxure_white_11.jpg",
      "thumbnails/luxure_white_12.jpg"
    ]
  },
  {
    "name": "marita_beige",
    "path": "images/products/porcelain/marita_beige/",
    "main": "marita_beige_03.jpg",
    "images": [
      "marita_beige_01.jpg",
      "marita_beige_02.jpg",
      "marita_beige_03.jpg"
    ],
    "thumbnails": [
      "thumbnails/marita_beige_01.jpg",
      "thumbnails/marita_beige_02.jpg",
      "thumbnails/marita_beige_03.jpg"
    ]
  },
  {
    "name": "maurya",
    "path": "images/products/porcelain/maurya/",
    "main": "maurya_06.jpg",
    "images": [
      "maurya_01.jpg",
      "maurya_02.jpg",
      "maurya_03.jpg",
      "maurya_04.jpg",
      "maurya_05.jpg",
      "maurya_06.jpg",
      "maurya_08.jpg"
    ],
    "thumbnails": [
      "thumbnails/maurya_01.jpg",
      "thumbnails/maurya_02.jpg",
      "thumbnails/maurya_03.jpg",
      "thumbnails/maurya_04.jpg",
      "thumbnails/maurya_05.jpg",
      "thumbnails/maurya_06.jpg",
      "thumbnails/maurya_08.jpg"
    ]
  },
  {
    "name": "metal_silver",
    "path": "images/products/porcelain/metal_silver/",
    "main": "metal_silver_01.jpg",
    "images": [
      "A_Metal Silver.jpg",
      "A_Metal_Silver.jpg",
      "Metal Silver Staircase.jpg",
      "Metal_Silver.jpg",
      "metal_silver_01.jpg",
      "metal_silver_02.jpg",
      "Metal_Silver_Kitchen.jpg",
      "Metal_Silver_Staircase.jpg"
    ],
    "thumbnails": [
      "thumbnails/A_Metal Silver.jpg",
      "thumbnails/A_Metal_Silver.jpg",
      "thumbnails/Metal Silver Staircase.jpg",
      "thumbnails/Metal_Silver.jpg",
      "thumbnails/metal_silver_01.jpg",
      "thumbnails/metal_silver_02.jpg",
      "thumbnails/Metal_Silver_Kitchen.jpg",
      "thumbnails/Metal_Silver_Staircase.jpg"
    ]
  },
  {
    "name": "nero_elegante",
    "path": "images/products/porcelain/nero_elegante/",
    "main": "nero_elegante_01.jpg",
    "images": [
      "nero_elegante_01.jpg",
      "nero_elegante_main.jpg"
    ],
    "thumbnails": [
      "thumbnails/nero_elegante_01.jpg",
      "thumbnails/nero_elegante_main.jpg"
    ]
  },
  {
    "name": "nordic_grey",
    "path": "images/products/porcelain/nordic_grey/",
    "main": "nordic_grey_01.jpg",
    "images": [
      "nordic_grey_01.jpg",
      "nordic_grey_02.jpg",
      "nordic_grey_03.jpg",
      "nordic_grey_04.jpg"
    ],
    "thumbnails": [
      "thumbnails/nordic_grey_01.jpg",
      "thumbnails/nordic_grey_02.jpg",
      "thumbnails/nordic_grey_03.jpg",
      "thumbnails/nordic_grey_04.jpg"
    ]
  },
  {
    "name": "ocean_stone_grigio",
    "path": "images/products/porcelain/ocean_stone_grigio/",
    "main": "ocean_stone_grigio_01.jpg",
    "images": [
      "A_Ocean_Stone_Grigio.jpg",
      "ocean_stone_grigio_01.jpg",
      "ocean_stone_grigio_02.jpg",
      "ocean_stone_grigio_03.jpg",
      "ocean_stone_grigio_04.jpg",
      "Ocean_Stone_Grigio_Space1.jpg",
      "Ocean_Stone_Grigio_Space5.jpg",
      "Ocean_Stone_Grigio_Space6.jpg"
    ],
    "thumbnails": [
      "thumbnails/A_Ocean_Stone_Grigio.jpg",
      "thumbnails/ocean_stone_grigio_01.jpg",
      "thumbnails/ocean_stone_grigio_02.jpg",
      "thumbnails/ocean_stone_grigio_03.jpg",
      "thumbnails/ocean_stone_grigio_04.jpg",
      "thumbnails/Ocean_Stone_Grigio_Space1.jpg",
      "thumbnails/Ocean_Stone_Grigio_Space5.jpg",
      "thumbnails/Ocean_Stone_Grigio_Space6.jpg"
    ]
  },
  {
    "name": "onice",
    "path": "images/products/porcelain/onice/",
    "main": "onice_01.jpg",
    "images": [
      "onice_01.jpg",
      "onice_03.jpg"
    ],
    "thumbnails": [
      "thumbnails/onice_01.jpg",
      "thumbnails/onice_03.jpg"
    ]
  },
  {
    "name": "onice_pink",
    "path": "images/products/porcelain/onice_pink/",
    "main": "onice_pink_04.jpg",
    "images": [
      "onice_pink_01.jpg",
      "onice_pink_02.jpg",
      "onice_pink_03.jpg",
      "onice_pink_04.jpg"
    ],
    "thumbnails": [
      "thumbnails/onice_pink_01.jpg",
      "thumbnails/onice_pink_02.jpg",
      "thumbnails/onice_pink_03.jpg",
      "thumbnails/onice_pink_04.jpg"
    ]
  },
  {
    "name": "onice_turquise",
    "path": "images/products/porcelain/onice_turquise/",
    "main": "onice_turquise_01.jpg",
    "images": [
      "onice_turquise_01.jpg",
      "onice_turquise_02.jpg",
      "onice_turquise_03.jpg",
      "onice_turquise_04.jpg"
    ],
    "thumbnails": [
      "thumbnails/onice_turquise_01.jpg",
      "thumbnails/onice_turquise_02.jpg",
      "thumbnails/onice_turquise_03.jpg",
      "thumbnails/onice_turquise_04.jpg"
    ]
  },
  {
    "name": "onice_white",
    "path": "images/products/porcelain/onice_white/",
    "main": "onice_white_02.jpg",
    "images": [
      "onice_white_02.jpg",
      "onice_white_03.jpg",
      "onice_white_05.jpg"
    ],
    "thumbnails": [
      "thumbnails/onice_white_02.jpg",
      "thumbnails/onice_white_03.jpg",
      "thumbnails/onice_white_05.jpg"
    ]
  },
  {
    "name": "panda_white",
    "path": "images/products/porcelain/panda_white/",
    "main": "panda_white_01.jpg",
    "images": [
      "panda_white_01.jpg",
      "panda_white_02.jpg"
    ],
    "thumbnails": [
      "thumbnails/panda_white_01.jpg",
      "thumbnails/panda_white_02.jpg"
    ]
  },
  {
    "name": "pandora",
    "path": "images/products/porcelain/pandora/",
    "main": "pandora_01.jpg",
    "images": [
      "pandora_01.jpg",
      "pandora_02.jpg",
      "pandora_03.jpg",
      "pandora_04.jpg",
      "pandora_06.jpg",
      "pandora_07.jpg",
      "pandora_09.jpg",
      "pandora_10.jpg",
      "pandora_12.jpg",
      "pandora_main.jpg",
      "WhatsApp_Image_2026-01-05_at_14.02.59.jpeg",
      "WhatsApp_Image_2026-01-05_at_14.02.59_(1).jpeg",
      "WhatsApp_Image_2026-01-05_at_14.03.00.jpeg"
    ],
    "thumbnails": [
      "thumbnails/pandora_01.jpg",
      "thumbnails/pandora_02.jpg",
      "thumbnails/pandora_03.jpg",
      "thumbnails/pandora_04.jpg",
      "thumbnails/pandora_06.jpg",
      "thumbnails/pandora_07.jpg",
      "thumbnails/pandora_09.jpg",
      "thumbnails/pandora_10.jpg",
      "thumbnails/pandora_12.jpg",
      "thumbnails/pandora_main.jpg",
      "thumbnails/WhatsApp_Image_2026-01-05_at_14.02.59.jpeg",
      "thumbnails/WhatsApp_Image_2026-01-05_at_14.02.59_(1).jpeg",
      "thumbnails/WhatsApp_Image_2026-01-05_at_14.03.00.jpeg"
    ]
  },
  {
    "name": "peackok_blue",
    "path": "images/products/porcelain/peackok_blue/",
    "main": "peackok_blue_01.jpg",
    "images": [
      "peackok_blue_01.jpg",
      "peackok_blue_02.jpg",
      "peackok_blue_03.jpg"
    ],
    "thumbnails": [
      "thumbnails/peackok_blue_01.jpg",
      "thumbnails/peackok_blue_02.jpg",
      "thumbnails/peackok_blue_03.jpg"
    ]
  },
  {
    "name": "premium_gold",
    "path": "images/products/porcelain/premium_gold/",
    "main": "premium_gold_main.jpg",
    "images": [
      "A_premium_gold.jpg",
      "premium_gold_02.jpg",
      "Premium_Gold_3D.jpg",
      "premium_gold_main.jpg"
    ],
    "thumbnails": [
      "thumbnails/A_premium_gold.jpg",
      "thumbnails/premium_gold_02.jpg",
      "thumbnails/Premium_Gold_3D.jpg",
      "thumbnails/premium_gold_main.jpg"
    ]
  },
  {
    "name": "rolex_white",
    "path": "images/products/porcelain/rolex_white/",
    "main": "rolex_white_01.jpg",
    "images": [
      "rolex_white_01.jpg",
      "rolex_white_02.jpg",
      "rolex_white_04.jpg",
      "rolex_white_05.jpg"
    ],
    "thumbnails": [
      "thumbnails/rolex_white_01.jpg",
      "thumbnails/rolex_white_02.jpg",
      "thumbnails/rolex_white_04.jpg",
      "thumbnails/rolex_white_05.jpg"
    ]
  },
  {
    "name": "roman_travertine_digital",
    "path": "images/products/porcelain/roman_travertine_digital/",
    "main": "075-001_output-gigapixel-scale-2_00x.jpg",
    "images": [
      "075-001_output-gigapixel-scale-2_00x.jpg",
      "075-002_output-gigapixel-scale-2_00x.jpg",
      "075-003_output-gigapixel-scale-2_00x.jpg",
      "075-004_output-gigapixel-scale-2_00x.jpg",
      "080-001_output-gigapixel-scale-2_00x.jpg",
      "133-001_output-gigapixel-scale-2_00x.jpg",
      "133-002_output-gigapixel-scale-2_00x.jpg",
      "roman_travertine_digital_01.jpg",
      "roman_travertine_digital_02.jpg",
      "roman_travertine_digital_05.jpg",
      "roman_travertine_digital_06.jpg",
      "roman_travertine_digital_07.jpg",
      "roman_travertine_digital_08.jpg",
      "roman_travertine_digital_09.jpg",
      "roman_travertine_digital_10.jpg",
      "roman_travertine_digital_12.jpg",
      "roman_travertine_digital_14.jpg",
      "roman_travertine_digital_15.jpg",
      "roman_travertine_digital_16.jpg",
      "roman_travertine_digital_17.jpg",
      "roman_travertine_digital_18.jpg",
      "roman_travertine_digital_19.jpg"
    ],
    "thumbnails": [
      "thumbnails/075-001_output-gigapixel-scale-2_00x.jpg",
      "thumbnails/075-002_output-gigapixel-scale-2_00x.jpg",
      "thumbnails/075-003_output-gigapixel-scale-2_00x.jpg",
      "thumbnails/075-004_output-gigapixel-scale-2_00x.jpg",
      "thumbnails/080-001_output-gigapixel-scale-2_00x.jpg",
      "thumbnails/133-001_output-gigapixel-scale-2_00x.jpg",
      "thumbnails/133-002_output-gigapixel-scale-2_00x.jpg",
      "thumbnails/roman_travertine_digital_01.jpg",
      "thumbnails/roman_travertine_digital_02.jpg",
      "thumbnails/roman_travertine_digital_05.jpg",
      "thumbnails/roman_travertine_digital_06.jpg",
      "thumbnails/roman_travertine_digital_07.jpg",
      "thumbnails/roman_travertine_digital_08.jpg",
      "thumbnails/roman_travertine_digital_09.jpg",
      "thumbnails/roman_travertine_digital_10.jpg",
      "thumbnails/roman_travertine_digital_12.jpg",
      "thumbnails/roman_travertine_digital_14.jpg",
      "thumbnails/roman_travertine_digital_15.jpg",
      "thumbnails/roman_travertine_digital_16.jpg",
      "thumbnails/roman_travertine_digital_17.jpg",
      "thumbnails/roman_travertine_digital_18.jpg",
      "thumbnails/roman_travertine_digital_19.jpg"
    ]
  },
  {
    "name": "sakura_rossa",
    "path": "images/products/porcelain/sakura_rossa/",
    "main": "sakura_rossa_01.jpg",
    "images": [
      "sakura_rossa_01.jpg",
      "sakura_rossa_02.jpg",
      "sakura_rossa_03.jpg",
      "sakura_rossa_04.jpg",
      "sakura_rossa_05.jpg",
      "sakura_rossa_06.jpg",
      "sakura_rossa_08.jpg"
    ],
    "thumbnails": [
      "thumbnails/sakura_rossa_01.jpg",
      "thumbnails/sakura_rossa_02.jpg",
      "thumbnails/sakura_rossa_03.jpg",
      "thumbnails/sakura_rossa_04.jpg",
      "thumbnails/sakura_rossa_05.jpg",
      "thumbnails/sakura_rossa_06.jpg",
      "thumbnails/sakura_rossa_08.jpg"
    ]
  },
  {
    "name": "silver_travertino",
    "path": "images/products/porcelain/silver_travertino/",
    "main": "silver_travertino_01.jpg",
    "images": [
      "silver_travertino_01.jpg",
      "silver_travertino_02.jpg",
      "silver_travertino_03.jpg",
      "silver_travertino_04.jpg"
    ],
    "thumbnails": [
      "thumbnails/silver_travertino_01.jpg",
      "thumbnails/silver_travertino_02.jpg",
      "thumbnails/silver_travertino_03.jpg",
      "thumbnails/silver_travertino_04.jpg"
    ]
  },
  {
    "name": "taj_mahal_matt",
    "path": "images/products/porcelain/taj_mahal_matt/",
    "main": "Taj Mahal Space2.jpg",
    "images": [
      "Taj Mahal Space2.jpg",
      "Taj Mahal Space3.jpg",
      "taj_mahal_matt_01.jpg",
      "taj_mahal_matt_02.jpg",
      "taj_mahal_matt_03.jpg",
      "taj_mahal_matt_05.jpg",
      "taj_mahal_matt_10.jpg",
      "taj_mahal_matt_11.jpg",
      "taj_mahal_matt_14.jpg",
      "taj_mahal_matt_15.jpg",
      "taj_mahal_matt_16.jpg",
      "taj_mahal_matt_17.jpg",
      "taj_mahal_matt_18.jpg",
      "taj_mahal_matt_19.jpg",
      "taj_mahal_matt_20.jpg",
      "taj_mahal_matt_21.jpg",
      "Taj_Mahal_Space2.jpg",
      "Taj_Mahal_Space3.jpg",
      "Taj_Mahal_Space4.jpg",
      "Taj_Mahal_Space6.jpg",
      "WhatsApp_Image_2026-05-03_at_10.50.07.jpeg"
    ],
    "thumbnails": [
      "thumbnails/Taj Mahal Space2.jpg",
      "thumbnails/Taj Mahal Space3.jpg",
      "thumbnails/taj_mahal_matt_01.jpg",
      "thumbnails/taj_mahal_matt_02.jpg",
      "thumbnails/taj_mahal_matt_03.jpg",
      "thumbnails/taj_mahal_matt_05.jpg",
      "thumbnails/taj_mahal_matt_10.jpg",
      "thumbnails/taj_mahal_matt_11.jpg",
      "thumbnails/taj_mahal_matt_14.jpg",
      "thumbnails/taj_mahal_matt_15.jpg",
      "thumbnails/taj_mahal_matt_16.jpg",
      "thumbnails/taj_mahal_matt_17.jpg",
      "thumbnails/taj_mahal_matt_18.jpg",
      "thumbnails/taj_mahal_matt_19.jpg",
      "thumbnails/taj_mahal_matt_20.jpg",
      "thumbnails/taj_mahal_matt_21.jpg",
      "thumbnails/Taj_Mahal_Space2.jpg",
      "thumbnails/Taj_Mahal_Space3.jpg",
      "thumbnails/Taj_Mahal_Space4.jpg",
      "thumbnails/Taj_Mahal_Space6.jpg",
      "thumbnails/WhatsApp_Image_2026-05-03_at_10.50.07.jpeg"
    ]
  },
  {
    "name": "taj_mahal_polished",
    "path": "images/products/porcelain/taj_mahal_polished/",
    "main": "taj_mahal_polished_02.jpg",
    "images": [
      "taj_mahal_polished_02.jpg",
      "taj_mahal_polished_03.jpg",
      "taj_mahal_polished_04.jpg",
      "Taj_Mahal_Polished_1.jpg",
      "Taj_Mahal_Polished_2.jpg",
      "Taj_Mahal_Polished_3.jpg",
      "Taj_Mahal_Polished_4.jpg"
    ],
    "thumbnails": [
      "thumbnails/taj_mahal_polished_02.jpg",
      "thumbnails/taj_mahal_polished_03.jpg",
      "thumbnails/taj_mahal_polished_04.jpg",
      "thumbnails/Taj_Mahal_Polished_1.jpg",
      "thumbnails/Taj_Mahal_Polished_2.jpg",
      "thumbnails/Taj_Mahal_Polished_3.jpg",
      "thumbnails/Taj_Mahal_Polished_4.jpg"
    ]
  },
  {
    "name": "tinta_onita_nero_matt",
    "path": "images/products/porcelain/tinta_onita_nero_matt/",
    "main": "A_tinta onita nero matt 1.png",
    "images": [
      "A_tinta onita nero matt 1.png",
      "A_tinta_onita_nero_matt_1.png",
      "tinta_onita_nero_matt.JPG",
      "tinta_onita_nero_matt_02.jpg"
    ],
    "thumbnails": [
      "thumbnails/A_tinta onita nero matt 1.png",
      "thumbnails/A_tinta_onita_nero_matt_1.png",
      "thumbnails/tinta_onita_nero_matt.JPG",
      "thumbnails/tinta_onita_nero_matt_02.jpg"
    ]
  }
];
